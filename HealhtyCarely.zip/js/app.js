import { isWeb } from './modules/testweb.js';

import { isMenu } from './modules/menu.js';

import { isSwaper } from './modules/swiper.js';

isWeb();
isMenu();
isSwaper();
